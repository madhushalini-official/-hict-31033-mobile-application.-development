package com.example.fieldresearchchecklist

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.navigation.compose.*
import com.example.fieldresearchchecklist.ui.CreateTaskScreen
import com.example.fieldresearchchecklist.ui.TaskListScreen
import com.example.fieldresearchchecklist.ui.theme.FieldResearchTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FieldResearchTheme(darkTheme = isSystemInDarkTheme()) {
                FieldResearchApp()
            }
        }
    }
}

@Composable
fun FieldResearchApp() {
    val navController = rememberNavController()
    val taskList = remember { mutableStateListOf<String>() }

    NavHost(navController = navController, startDestination = "task_list") {
        composable("task_list") {
            TaskListScreen(taskList, navController)
        }
        composable("create_task") {
            CreateTaskScreen(taskList, navController)
        }
    }
}
